package UGraph;
require Graph::Undirected;
@UGraph::ISA=qw(Graph::Undirected);
1;
